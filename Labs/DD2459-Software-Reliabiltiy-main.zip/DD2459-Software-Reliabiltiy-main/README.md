# DD2459-Software-Reliabiltiy
Lab session for course DD2459 - Software Reliability, includes black-box and requirement-based testing: sorting and searching

## Lab2 - black-box and requirement-based testing: sorting and searching
Codes to generate random number and combination of pairs test suites. Also we write an oracle that automatically judges each test outcome. 